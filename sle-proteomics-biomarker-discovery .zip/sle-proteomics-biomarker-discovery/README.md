# SLE/LN Proteomics Biomarker Discovery

![Python](https://img.shields.io/badge/Python-3.10%2B-blue)
![Research](https://img.shields.io/badge/Domain-Immunology%20%7C%20Proteomics-purple)
![Data](https://img.shields.io/badge/Data-Synthetic-orange)
![Tests](https://img.shields.io/badge/Tests-pytest-green)

A reproducible bioinformatics portfolio project demonstrating a **proteomics-to-biomarker-discovery workflow** for systemic lupus erythematosus (SLE) and lupus nephritis (LN).

> **Important:** All data and numerical results in this repository are synthetic and are provided only for computational demonstration. They are not patient data and are not the user's actual thesis results.

## Research question

Can proteomic profiles be analyzed systematically to identify candidate proteins associated with SLE/LN disease biology and evaluate their potential discriminatory performance?

## Workflow

```text
Synthetic proteomics matrix
          |
          v
Data quality / missing-value handling
          |
          v
Differential protein expression
          |
          +----------------------+
          |                      |
          v                      v
     Volcano plot          Candidate selection
                                 |
                                 v
                       ROC / AUC analysis
                                 |
                                 v
                       Disease-activity correlation
                                 |
                                 v
                    Biological interpretation
```

## Study design represented by the synthetic data

| Group | Samples |
|---|---:|
| Control | 51 |
| Active SLE | 51 |
| Lupus Nephritis | 51 |
| **Total** | **153** |

The dataset contains 60+ simulated protein measurements spanning inflammatory, complement, interferon, endothelial, extracellular-matrix and immune-related biology.

## Repository structure

```text
sle-proteomics-biomarker-discovery/
├── .github/
│   └── workflows/
│       └── tests.yml
├── data/
│   ├── README.md
│   ├── synthetic_clinical_metadata.csv
│   └── synthetic_proteomics_matrix.csv
├── notebooks/
│   └── 01_proteomics_biomarker_analysis.ipynb
├── results/
│   ├── figures/
│   │   ├── 01_volcano_plot.png
│   │   ├── 02_candidate_biomarker_heatmap.png
│   │   ├── 03_candidate_boxplots.png
│   │   └── 04_roc_curves.png
│   ├── analysis_summary.json
│   ├── biomarker_activity_correlations.csv
│   ├── biomarker_auc_ranking.csv
│   └── differential_expression_SLE_vs_control.csv
├── src/
│   ├── analysis.py
│   ├── run_analysis.py
│   └── visualization.py
├── tests/
│   └── test_analysis.py
├── .gitignore
├── LICENSE
├── pyproject.toml
├── README.md
└── requirements.txt
```

## Analysis performed

### 1. Data preprocessing

The workflow:

- Loads proteomic and clinical metadata
- Identifies protein features
- Performs simple median imputation for demonstration
- Preserves sample/group metadata

### 2. Differential expression

Active SLE is compared with Control using Welch's two-sample t-test.

Candidate thresholds are:

- `|log2FC| >= 0.58`
- `FDR < 0.05`

The threshold corresponds approximately to a 1.5-fold change.

### 3. Biomarker evaluation

Candidate proteins are evaluated using:

- ROC curves
- Area under the ROC curve (AUC)
- Individual biomarker ranking

### 4. Disease-activity association

Candidate protein abundance can be correlated with the synthetic SLEDAI score using Spearman correlation.

## Visual outputs

The pipeline generates:

**Volcano plot**

Shows effect size and statistical significance.

**Candidate biomarker heatmap**

Shows standardized abundance patterns across study groups.

**Protein boxplots**

Shows group-level distributions for selected candidate biomarkers.

**ROC curves**

Shows discriminatory performance of candidate proteins between Control and Active SLE.

## Running the project

### 1. Clone

```bash
git clone https://github.com/YOUR_USERNAME/sle-proteomics-biomarker-discovery.git
cd sle-proteomics-biomarker-discovery
```

### 2. Create virtual environment

macOS/Linux:

```bash
python -m venv .venv
source .venv/bin/activate
```

Windows:

```powershell
python -m venv .venv
.venv\Scripts\activate
```

### 3. Install packages

```bash
pip install -r requirements.txt
```

### 4. Run the complete analysis

```bash
python -m src.run_analysis
```

### 5. Run tests

```bash
pytest
```

## Scientific interpretation

This repository demonstrates the **computational workflow**, not clinical validation.

A protein can show statistical differential expression without being a clinically useful biomarker. Biomarker development requires additional assessment including:

- Independent cohort validation
- Analytical reproducibility
- Pre-analytical standardization
- Treatment-related confounding
- Biological specificity
- Sensitivity/specificity assessment
- Calibration and decision-curve analysis
- Prospective validation

For SLE/LN research, important clinical confounders can include disease activity, renal involvement, medications, sample type, collection conditions, demographic factors and comorbidities.

## Why synthetic data?

The repository is intentionally safe to publish publicly. No patient identifiers, clinical records or proprietary proteomics files are included.

When real research data are used, the data-sharing process should comply with the applicable ethics approval, consent, institutional policy and data-protection requirements.

## Future extensions

### Version 2 — Multi-biomarker model

Build a logistic-regression or machine-learning model combining multiple proteins.

### Version 3 — Explainable ML

Add SHAP-based feature importance.

### Version 4 — Pathway analysis

Integrate GO/KEGG enrichment using an appropriate annotation source.

### Version 5 — External validation

Evaluate the signature on an independent cohort.

### Version 6 — Interactive dashboard

Build a Streamlit interface for:

- Protein selection
- Group comparison
- Volcano plots
- ROC analysis
- Clinical correlation

## Skills demonstrated

**Immunology · Proteomics · Biomarker Discovery · Bioinformatics · Python · Pandas · NumPy · SciPy · scikit-learn · Statistical Analysis · ROC/AUC · Data Visualization · Jupyter · Reproducible Research · GitHub Actions**

## Author

**Ranjan V**

Biomedical Researcher | Immunology | Proteomics | Biomarker Discovery | Bioinformatics
