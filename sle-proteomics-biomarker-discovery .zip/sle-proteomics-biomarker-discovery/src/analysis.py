
from pathlib import Path
import numpy as np
import pandas as pd
from scipy import stats
from sklearn.metrics import roc_auc_score, roc_curve
from sklearn.impute import SimpleImputer

GROUPS = ["Control", "Active_SLE", "Lupus_Nephritis"]

def load_data(proteomics_path, clinical_path=None):
    proteomics = pd.read_csv(proteomics_path)
    clinical = pd.read_csv(clinical_path) if clinical_path else None
    return proteomics, clinical

def protein_columns(df):
    return [c for c in df.columns if c not in {"sample_id", "group"}]

def median_impute(df, cols):
    out = df.copy()
    for c in cols:
        out[c] = out[c].fillna(out[c].median())
    return out

def differential_expression(df, group_a="Control", group_b="Active_SLE"):
    rows = []
    for protein in protein_columns(df):
        a = df.loc[df["group"] == group_a, protein].dropna()
        b = df.loc[df["group"] == group_b, protein].dropna()

        t_stat, p_value = stats.ttest_ind(b, a, equal_var=False)

        mean_a = a.mean()
        mean_b = b.mean()
        log2fc = mean_b - mean_a

        rows.append({
            "protein": protein,
            "mean_control": mean_a,
            "mean_comparison": mean_b,
            "log2FC": log2fc,
            "fold_change": 2 ** log2fc,
            "p_value": p_value,
        })

    result = pd.DataFrame(rows)
    result["fdr"] = multipletest_bh(result["p_value"].values)
    result["significant"] = (result["fdr"] < 0.05) & (result["log2FC"].abs() >= 0.58)
    return result.sort_values("p_value")

def multipletest_bh(pvalues):
    pvalues = np.asarray(pvalues, dtype=float)
    n = len(pvalues)
    order = np.argsort(pvalues)
    ranked = pvalues[order]
    adjusted = ranked * n / np.arange(1, n + 1)
    adjusted = np.minimum.accumulate(adjusted[::-1])[::-1]
    out = np.empty(n)
    out[order] = np.clip(adjusted, 0, 1)
    return out

def biomarker_roc(df, protein, positive_group="Active_SLE", negative_group="Control"):
    sub = df[df["group"].isin([positive_group, negative_group])][["group", protein]].dropna()
    y = (sub["group"] == positive_group).astype(int)
    auc = roc_auc_score(y, sub[protein])
    fpr, tpr, thresholds = roc_curve(y, sub[protein])
    return {"auc": float(auc), "fpr": fpr, "tpr": tpr, "thresholds": thresholds}

def rank_biomarkers(df, proteins, positive_group="Active_SLE", negative_group="Control"):
    rows = []
    for protein in proteins:
        try:
            result = biomarker_roc(df, protein, positive_group, negative_group)
            rows.append({"protein": protein, "auc": result["auc"]})
        except ValueError:
            continue
    return pd.DataFrame(rows).sort_values("auc", ascending=False)

def correlate_with_activity(df, clinical, proteins, group="Active_SLE"):
    merged = df.merge(clinical, on=["sample_id", "group"])
    sub = merged[merged["group"] == group]
    rows = []
    for protein in proteins:
        valid = sub[[protein, "sledaI_score"]].dropna()
        if len(valid) >= 5:
            rho, p = stats.spearmanr(valid[protein], valid["sledaI_score"])
            rows.append({"protein": protein, "spearman_rho": rho, "p_value": p})
    return pd.DataFrame(rows).sort_values("p_value")
