
from pathlib import Path
import json
from src.analysis import (
    load_data, protein_columns, median_impute,
    differential_expression, rank_biomarkers, correlate_with_activity
)
from src.visualization import volcano_plot, heatmap, boxplots, roc_plot

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
RESULTS = ROOT / "results"
FIG = RESULTS / "figures"

def main():
    proteomics, clinical = load_data(
        DATA / "synthetic_proteomics_matrix.csv",
        DATA / "synthetic_clinical_metadata.csv"
    )

    proteins = protein_columns(proteomics)
    clean = median_impute(proteomics, proteins)

    de = differential_expression(clean)
    de.to_csv(RESULTS / "differential_expression_SLE_vs_control.csv", index=False)

    candidate = de.loc[de["significant"], "protein"].tolist()
    candidate = candidate[:12]
    if len(candidate) < 5:
        candidate = de.head(8)["protein"].tolist()

    roc_rank = rank_biomarkers(clean, candidate)
    roc_rank.to_csv(RESULTS / "biomarker_auc_ranking.csv", index=False)

    correlations = correlate_with_activity(clean, clinical, candidate)
    correlations.to_csv(RESULTS / "biomarker_activity_correlations.csv", index=False)

    volcano_plot(de, FIG / "01_volcano_plot.png")
    heatmap(clean, candidate, FIG / "02_candidate_biomarker_heatmap.png")
    boxplots(clean, candidate[:5], FIG / "03_candidate_boxplots.png")
    roc_plot(clean, candidate[:5], FIG / "04_roc_curves.png")

    summary = {
        "samples": len(proteomics),
        "proteins": len(proteins),
        "significant_proteins": int(de["significant"].sum()),
        "candidate_biomarkers_plotted": candidate[:5],
    }
    (RESULTS / "analysis_summary.json").write_text(json.dumps(summary, indent=2))

    print(json.dumps(summary, indent=2))

if __name__ == "__main__":
    main()
