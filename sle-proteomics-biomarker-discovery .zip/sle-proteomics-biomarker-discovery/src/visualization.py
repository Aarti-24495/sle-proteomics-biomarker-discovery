
from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt

def volcano_plot(de, output):
    fig, ax = plt.subplots(figsize=(10, 7))
    x = de["log2FC"]
    y = -np.log10(de["p_value"].clip(lower=1e-300))
    sig = de["significant"]

    ax.scatter(x[~sig], y[~sig], alpha=0.55, s=24, label="Not significant")
    ax.scatter(x[sig], y[sig], alpha=0.8, s=32, label="Significant")
    ax.axvline(0.58, linestyle="--", linewidth=1)
    ax.axvline(-0.58, linestyle="--", linewidth=1)
    ax.axhline(-np.log10(0.05), linestyle="--", linewidth=1)

    for _, row in de[sig].head(10).iterrows():
        ax.annotate(row["protein"], (row["log2FC"], -np.log10(row["p_value"])),
                    xytext=(4, 4), textcoords="offset points", fontsize=8)

    ax.set_title("Differential Protein Expression: Active SLE vs Control")
    ax.set_xlabel("log2 fold change")
    ax.set_ylabel("-log10(p-value)")
    ax.legend()
    fig.tight_layout()
    fig.savefig(output, dpi=200)
    plt.close(fig)

def heatmap(df, proteins, output):
    sub = df.set_index("sample_id")[proteins]
    sub = sub.sub(sub.mean()).div(sub.std().replace(0, 1))
    order = df.set_index("sample_id")["group"].map(
        {"Control":0, "Active_SLE":1, "Lupus_Nephritis":2}
    ).sort_values().index
    sub = sub.loc[order]

    fig, ax = plt.subplots(figsize=(12, 7))
    im = ax.imshow(sub.T.values, aspect="auto", interpolation="nearest")
    ax.set_title("Standardized Expression of Candidate Biomarkers")
    ax.set_xlabel("Samples ordered by study group")
    ax.set_ylabel("Protein")
    ax.set_yticks(range(len(proteins)))
    ax.set_yticklabels(proteins)
    fig.colorbar(im, ax=ax, label="Z-score")
    fig.tight_layout()
    fig.savefig(output, dpi=200)
    plt.close(fig)

def boxplots(df, proteins, output):
    n = len(proteins)
    fig, axes = plt.subplots(n, 1, figsize=(9, 3*n), squeeze=False)
    for i, protein in enumerate(proteins):
        ax = axes[i,0]
        groups = ["Control", "Active_SLE", "Lupus_Nephritis"]
        vals = [df.loc[df["group"] == g, protein].dropna().values for g in groups]
        ax.boxplot(vals, labels=groups)
        ax.set_title(protein)
        ax.set_ylabel("log2 abundance")
    fig.tight_layout()
    fig.savefig(output, dpi=200)
    plt.close(fig)

def roc_plot(df, proteins, output):
    from sklearn.metrics import roc_curve, roc_auc_score

    fig, ax = plt.subplots(figsize=(8, 7))
    for protein in proteins:
        sub = df[df["group"].isin(["Control", "Active_SLE"])][["group", protein]].dropna()
        y = (sub["group"] == "Active_SLE").astype(int)
        auc = roc_auc_score(y, sub[protein])
        fpr, tpr, _ = roc_curve(y, sub[protein])
        ax.plot(fpr, tpr, label=f"{protein} (AUC={auc:.3f})")

    ax.plot([0,1], [0,1], linestyle="--", linewidth=1)
    ax.set_title("ROC Curves: Candidate Biomarkers")
    ax.set_xlabel("False positive rate")
    ax.set_ylabel("True positive rate")
    ax.legend()
    fig.tight_layout()
    fig.savefig(output, dpi=200)
    plt.close(fig)
