# Synthetic dataset

This folder contains **fully synthetic** data created for demonstrating a reproducible proteomics/biomarker-discovery workflow.

It is not patient data and must not be interpreted as a clinical dataset or as the user's actual thesis results.

Files:

- `synthetic_proteomics_matrix.csv` — 153 samples × 62 proteins plus metadata columns.
- `synthetic_clinical_metadata.csv` — synthetic demographic and disease-activity variables.

The synthetic structure represents three groups:

- Control (n=51)
- Active SLE (n=51)
- Lupus Nephritis (n=51)

The simulated protein signals include examples relevant to inflammation, complement, interferon signaling, endothelial activation, extracellular matrix biology and immune pathways.
