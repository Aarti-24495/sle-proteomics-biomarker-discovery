
import pandas as pd
from src.analysis import differential_expression, median_impute

def test_differential_expression_returns_expected_columns():
    df = pd.DataFrame({
        "sample_id": ["C1","C2","S1","S2"],
        "group": ["Control","Control","Active_SLE","Active_SLE"],
        "P1": [1.0, 1.2, 2.0, 2.2],
        "P2": [2.0, 2.1, 2.0, 2.2],
    })
    result = differential_expression(df)
    assert {"protein","log2FC","p_value","fdr","significant"}.issubset(result.columns)
    assert len(result) == 2

def test_median_imputation_removes_missing_values():
    df = pd.DataFrame({
        "sample_id": ["A","B","C"],
        "group": ["Control","Control","Active_SLE"],
        "P1": [1.0, None, 3.0]
    })
    out = median_impute(df, ["P1"])
    assert out["P1"].isna().sum() == 0
